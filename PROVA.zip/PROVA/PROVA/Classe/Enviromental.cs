﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace backend1
{
    class Enviromental
    {
        private Hardware hardware;
        private Software software;



        //teste somente no hardware
        public Enviromental(string deviceType, string modelNumber)
        {


            hardware = new Hardware(deviceType, modelNumber);


        }
        
        //teste somente no software
        public Enviromental(string sistemaOperacional, string softwareVersion, string type)
        {



            software = new Software(sistemaOperacional, softwareVersion, type);

        }

        //teste com hardware ou software
        public Enviromental (string deviceType, string modelNumber, string sistemaOperacional, string softwareVersion, string type){


            hardware = new Hardware(deviceType, modelNumber);
            software = new Software(sistemaOperacional, softwareVersion,type);

        }




    }
}
