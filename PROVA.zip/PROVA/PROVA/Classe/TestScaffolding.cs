﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace backend1
{
    public class TestScaffolding
    {
        private string Scaff_ID;
        private string Scaff_Type;
        private string Scaff_Class;
        private string Scaff_Package;

        public void setID(string id)
        {
            this.Scaff_ID = id;
        }
        public string getID()
        {
            return this.Scaff_ID;
        }
        /*************************/
        public void setType(string type)
        {
            this.Scaff_Type = type;
        }
      
        public string getScaff_Type()
        {
            return this.Scaff_Type;
        }
          /****************************/
        public void setClass(string clas)
        {
            this.Scaff_Class = clas;
        }
        public string getClass ()
        {
            return this.Scaff_Class;
        }
        /****************************/

        public void setPackage(string pack)
        {
            this.Scaff_Package = pack;
        }
        public string getPackage()
        {
            return this.Scaff_Package;
        }
    }
}
