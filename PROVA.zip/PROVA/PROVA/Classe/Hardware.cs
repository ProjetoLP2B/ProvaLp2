﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace backend1
{
    class Hardware
    {

        //fields
        private string _deviceType = string.Empty;
        private string _modelNumber = string.Empty;

        //construtor
        public Hardware(string deviceType, string modelNumber)
        {
            _deviceType = deviceType;
            _modelNumber = modelNumber;

        }

        //metodos Get
        public string GetDeviceType()
        {

            return _deviceType;

        }

        public string GetModelNumber()
        {

            return _modelNumber;

        }


    }
}
