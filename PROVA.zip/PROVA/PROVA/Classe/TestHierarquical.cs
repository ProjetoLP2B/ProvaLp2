﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace backend1
{
    public class TestHierarchical
    {
        private string Test_ID;
        private string Test_Name;
        private string Classe;
        private string Package;

        public TestHierarchical(string id, string name, string classe, string package)
        {
            Test_ID = id;
            Test_Name = name;
            Classe = classe;
            Package = package;
        }

        public void setID(string id)
        {
            this.Test_ID = id;
        }
        public string getID()
        {
            return Test_ID;
        }

        public void setName(string nome)
        {
            this.Test_Name = nome;
        }
        public string getName()
        {
            return Test_Name;
        }

        public void setClass(string cs)
        {
            this.Classe = cs;
        }
        public string getClass()
        {
            return this.Classe;
        }

        public void setPackage(string pack)
        {
            this.Package = pack;
        }
        public string getPackage()
        {
            return this.Package;
        }
    }
}
