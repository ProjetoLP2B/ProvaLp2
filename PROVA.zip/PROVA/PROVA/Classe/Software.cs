﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace backend1
{
    public class Software
    {
        private string OS;
        private string Software_Version;
        private string Tipo;

        public Software(string sistemaOperacional, string softwareVersion, string type)
        {

            OS = sistemaOperacional;
            Software_Version = softwareVersion;
            Tipo = type;


        }

        public string getOS()
        {
            return this.OS;
        }
        public void setOS(string os)
        {
            this.OS = os;
        }

        public string getSoft_Version()
        {
            return this.Software_Version;
        }
        public void setSoft_Version(string soft_vers)
        {
            this.Software_Version = soft_vers;
        }

        public string getTipo()
        {
            return this.Tipo;
        }
        public void setTipo(string tipo)
        {
            this.Tipo = tipo;
        }

        /*
                 void Cadastrar(string x, string y, string z)
                {
                    setOS(x);
                    setTipo(y);
                    setSoft_Version(z);
                    try
                    {
                        Dao dao = new Dao();
                        dao.insereSoftware(this.Software);
                    }
                    catch (Excepcion x)
                    {
                        Messagebox.Show("Mano deu merda", x.Message);
                    }
                }
 
         */
    }
}