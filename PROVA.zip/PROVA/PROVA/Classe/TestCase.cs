﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace backend1
{
    class TestCase
    {
        private string _id;
        private string _testName;
        private string _classe;
        private string _package;
        /*
        private string _modelHardware;
        private int _softwareId;
        */

        //construtor
        //modelHardware é passado pelo front
        public TestCase(string id, string testName, string classe, string package ){

            _id = id;
            _testName = testName;
            _classe = classe;
            _package = package;
            /*
            _modelHardware = modelHardware;
            _softwareId = softwareId;
            */
        }


        
       
        //listas de objetos
        private List<TestHierarchical> listTestHierarchical = new List<TestHierarchical>();
        private List<Enviromental> listEnviromental = new List<Enviromental>();
        private List<Internal> listInternal = new List<Internal>();


        //add objetos às listas
        public void AddTestHierarchical(TestHierarchical instancia){

            listTestHierarchical.Add(instancia);
        }

        public void AddEnviromental(Enviromental instancia){

            listEnviromental.Add(instancia);
        }

        public void AddInternal(Internal instancia){

            listInternal.Add(instancia);

        }

        //get lists
        public List<TestHierarchical> getListTestHierarchical(){

            return listTestHierarchical;

        }

        public List<Enviromental> getListEnviromental(){

            return listEnviromental;

        }

        public List<Internal> getListInternal(){

            return listInternal;

        }

    }
}