﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace backend1
{
    public class CUT
    {
        private string cut_ID;
        private string cut_Comp_Name;
        private string cut_Package;


        public CUT(string id, string componentName, string package)
        {

            cut_ID = id;
            cut_Comp_Name = componentName;
            cut_Package = package;

        }

        public void setID(string id)
        {
            this.cut_ID = id;
        }
        public string getCutID()
        {
            return this.cut_ID;
        }

        public void setCompName(string CompName)
        {
            this.cut_Comp_Name = CompName;
        }
        public string getCompName()
        {
            return this.cut_Comp_Name;
        }

        public void setPackage(string package)
        {
            this.cut_Package = package;
        }

        public string getPackage()
        {
            return this.cut_Package;
        }
    }
}
