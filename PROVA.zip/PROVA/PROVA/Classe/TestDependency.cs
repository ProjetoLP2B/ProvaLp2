﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace backend1
{
    class TestDependency
    {
        private List<TestCase> listTestDependencies = new List<TestCase>();

        public void AddEnviromental(TestCase instancia){

            listTestDependencies.Add(instancia);
        }

    }
}
