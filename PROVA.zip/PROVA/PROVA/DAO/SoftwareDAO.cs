﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test.Dao
{
    class SoftwareDAO:Conexao
    {
        #region Metodo Para Salvar

        public void Salvar(ClassSoftware software)
        {
            try
            {
                AbrirConexao();
                comando = new MySqlCommand("INSERT INTO Software (OS, SoftwareVersion, Tipo) VALUES (@OS, @SoftwareVersion, @Tipo)", conexao);

                comando.Parameters.AddWithValue("@OS", software.OS);
                comando.Parameters.AddWithValue("@SoftwareVersion", software.SoftwareVersion);
                comando.Parameters.AddWithValue("@Tipo", software.Type);

                comando.ExecuteNonQuery();
            }
            catch (Exception erro)
            {

                throw erro;
            }
            finally
            {
                FecharConexao();
            }
        }
        #endregion

        #region Metodo para listar no Daragridview

        public DataTable Listar()
        {
            try
            {
                AbrirConexao();

                DataTable DT = new DataTable();
                MySqlDataAdapter Da = new MySqlDataAdapter();

                comando = new MySqlCommand("SELECT * FROM Software ORDER BY nome", conexao);

                Da.SelectCommand = comando;

                Da.Fill(DT);

                return DT;
            }
            catch (Exception erro)
            {

                throw erro;
            }
            finally
            {
                FecharConexao();
            }
        }
        #endregion

        #region Metodo para Editar os dados da pessoa

        public void Editar(ClassSoftware software)
        {
            try
            {
                AbrirConexao();

                comando = new MySqlCommand("UPDATE Softwarer SET ID = @ID, ComponentName = @ComponentName, Package = @Package", conexao);

                comando.Parameters.AddWithValue("@OS", software.OS);
                comando.Parameters.AddWithValue("@SoftwareVersion", software.SoftwareVersion);
                comando.Parameters.AddWithValue("@Tipo", software.Type);

                comando.ExecuteNonQuery();

            }
            catch (Exception erro)
            {

                throw erro;
            }

            finally
            {
                FecharConexao();
            }
        }
        #endregion

        #region Metodo para Exclui os dados da pessoa

        public void Excluir(ClassSoftware software)
        {
            try
            {
                AbrirConexao();

                comando = new MySqlCommand("DELETE FROM  Cut WHERE ID = @ID", conexao);

                comando.Parameters.AddWithValue("@OS", software.OS);

                comando.ExecuteNonQuery();


            }
            catch (Exception erro)
            {

                throw erro;
            }

            finally
            {
                FecharConexao();
            }
        }

        #endregion
    }
}
