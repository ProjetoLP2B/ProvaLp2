﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;


namespace test
{
    public class Conexao
    {
        string conecta = "";
        protected MySqlConnection conexao = null;
        public MySqlCommand comando = null;
        
        #region Método para conectar no banco

        public void AbrirConexao()
        {
            try
            {
                conexao = new MySqlConnection(conecta);
                conexao.Open();
            }
            catch (Exception erro)
            {

                throw erro;
            }
        }

        #endregion

        #region Método para Desconectar com o banco 

        public void FecharConexao()
        {
            try
            {
                conexao = new MySqlConnection(conecta);
                conexao.Close();
            }
            catch (Exception erro)
            {

                throw erro;
            }

        }

        #endregion

    }
}
