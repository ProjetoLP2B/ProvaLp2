﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test.Dao
{
    class HardwareDAO:Conexao
    {
        #region Metodo Para Salvar 

        public void Salvar(ClassHardware hardware)
        {
            try
            {
                AbrirConexao();
                comando = new MySqlCommand("INSERT INTO Hardware (DeviceType, ModelNumber) VALUES (@DeviceType, @ModelNumber)", conexao);

                comando.Parameters.AddWithValue("@DeviceType", hardware.DeviceType);
                comando.Parameters.AddWithValue("@CompoModelNumber", hardware.ModelNumber);  

                comando.ExecuteNonQuery();
            }
            catch (Exception erro)
            {

                throw erro;
            }
            finally
            {
                FecharConexao();
            }
        }
        #endregion

        #region Metodo para listar no Daragridview

        public DataTable Listar()
        {
            try
            {
                AbrirConexao();

                DataTable DT = new DataTable();
                MySqlDataAdapter Da = new MySqlDataAdapter();

                comando = new MySqlCommand("SELECT * FROM Hardware ORDER BY nome", conexao);

                Da.SelectCommand = comando;

                Da.Fill(DT);

                return DT;
            }
            catch (Exception erro)
            {

                throw erro;
            }
            finally
            {
                FecharConexao();
            }
        }
        #endregion

        #region Metodo para Editar os dados da pessoa 

        public void Editar(ClassHardware hardware)
        {
            try
            {
                AbrirConexao();

                comando = new MySqlCommand("UPDATE Hardware SET ", conexao);

                comando.Parameters.AddWithValue("@DeviceType", hardware.DeviceType);
                comando.Parameters.AddWithValue("@CompoModelNumber", hardware.ModelNumber);


                comando.ExecuteNonQuery();

            }
            catch (Exception erro)
            {

                throw erro;
            }

            finally
            {
                FecharConexao();
            }
        }
        #endregion

        #region Metodo para Exclui os dados da pessoa

        public void Excluir(ClassHardware hardware)
        {
            try
            {
                AbrirConexao();
               
                comando = new MySqlCommand("DELETE FROM  Hardware WHERE ID = @ID", conexao);

                comando.Parameters.AddWithValue("@Id",hardware.ModelNumber);

                comando.ExecuteNonQuery();

            }
            catch (Exception erro)
            {

                throw erro;
            }

            finally
            {
                FecharConexao();
            }
        }

        #endregion
    }
}
