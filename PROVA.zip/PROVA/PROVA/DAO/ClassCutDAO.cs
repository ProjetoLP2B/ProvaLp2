﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using MySql.Data.MySqlClient;

namespace test
{
    public class ClassCutDAO: Conexao
    {

        #region Metodo Para Salvar 

        public void Salvar(ClassCUT  cut)
        {
            try
            {
                AbrirConexao();
                comando = new MySqlCommand("INSERT INTO CUT (ID, ComponentName, Package) VALUES (@ID, @ComponentName, @Package)", conexao);

                comando.Parameters.AddWithValue("@ID", cut.ID);
                comando.Parameters.AddWithValue("@ComponentName", cut.ComponentName);
                comando.Parameters.AddWithValue("@Package", cut.Package);
           
                comando.ExecuteNonQuery();
            }
            catch (Exception erro)
            {

                throw erro;
            }
            finally
            {
                FecharConexao();
            }
        }
        #endregion

        #region Metodo para listar no Daragridview

        public DataTable Listar()
        {
            try
            {
                AbrirConexao();

                DataTable DT = new DataTable();
                MySqlDataAdapter Da = new MySqlDataAdapter();

                comando = new MySqlCommand("SELECT * FROM CUT ORDER BY nome", conexao);

                Da.SelectCommand = comando;

                Da.Fill(DT);

                return DT;
            }
            catch (Exception erro)
            {

                throw erro;
            }
            finally
            {
                FecharConexao();
            }
        }
        #endregion

        #region Metodo para Editar os dados da pessoa 

        public void Editar(ClassCUT cut)
        {
            try
            {
                AbrirConexao();

                comando = new MySqlCommand("UPDATE cut SET ID = @ID, ComponentName = @ComponentName, Package =@ Package ", conexao);

                comando.Parameters.AddWithValue("@ID", cut.ID);
                comando.Parameters.AddWithValue("@ComponentName", cut.ComponentName);
                comando.Parameters.AddWithValue("@Package", cut.Package);


                comando.ExecuteNonQuery();

            }
            catch (Exception erro)
            {

                throw erro;
            }

            finally
            {
                FecharConexao();
            }
        }
        #endregion

        #region Metodo para Exclui os dados da pessoa

        public void Excluir(ClassCUT cut
            )
        {
            try
            {
                AbrirConexao();

                comando = new MySqlCommand("DELETE FROM  Cut WHERE ID = @ID", conexao);

                comando.Parameters.AddWithValue("@Id", cut.ID);

                comando.ExecuteNonQuery();

            }
            catch (Exception erro)
            {

                throw erro;
            }

            finally
            {
                FecharConexao();
            }
        }

        #endregion
    }
}
