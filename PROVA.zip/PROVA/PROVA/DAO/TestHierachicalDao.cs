﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test.Dao
{
    public class TestHierachicalDao: Conexao
    {
        #region Metodo Para Salvar

        public void Salvar(ClassTestHierachical testHierarquical)
        {
            try
            {
                AbrirConexao();
                comando = new MySqlCommand("", conexao);

                comando.Parameters.AddWithValue("@Test_ID", testHierarquical.ID);
                comando.Parameters.AddWithValue("@Test_Name", testHierarquical.TestName);
                comando.Parameters.AddWithValue("@Classe", testHierarquical.Class);
                comando.Parameters.AddWithValue("@Package", testHierarquical.Package);

                comando.ExecuteNonQuery();
            }
            catch (Exception erro)
            {

                throw erro;
            }
            finally
            {
                FecharConexao();
            }
        }
        #endregion

        #region Metodo para listar no Daragridview

        public DataTable Listar()
        {
            try
            {
                AbrirConexao();

                DataTable DT = new DataTable();
                MySqlDataAdapter Da = new MySqlDataAdapter();

                comando = new MySqlCommand("", conexao);

                Da.SelectCommand = comando;

                Da.Fill(DT);

                return DT;
            }
            catch (Exception erro)
            {

                throw erro;
            }
            finally
            {
                FecharConexao();
            }
        }
        #endregion

        #region Metodo para Editar os dados da pessoa

        public void Editar(ClassTestHierachical testHierarquical)
        {
            try
            {
                AbrirConexao();

                comando = new MySqlCommand("", conexao);

                comando.Parameters.AddWithValue("@Test_ID", testHierarquical.ID);
                comando.Parameters.AddWithValue("@Test_Name", testHierarquical.TestName);
                comando.Parameters.AddWithValue("@Classe", testHierarquical.Class);
                comando.Parameters.AddWithValue("@Package", testHierarquical.Package);

                comando.ExecuteNonQuery();

            }
            catch (Exception erro)
            {

                throw erro;
            }

            finally
            {
                FecharConexao();
            }
        }
        #endregion

        #region Metodo para Exclui os dados da pessoa

        public void Excluir(ClassTestHierachical testHierarquical)
        {
            try
            {
                AbrirConexao();

                comando = new MySqlCommand("", conexao);

                comando.Parameters.AddWithValue("@Test_ID", testHierarquical.ID);

                comando.ExecuteNonQuery();


            }
            catch (Exception erro)
            {

                throw erro;
            }

            finally
            {
                FecharConexao();
            }
        }

        #endregion
    }
}
