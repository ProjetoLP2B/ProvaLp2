﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using MySql.Data.MySqlClient;

namespace test
{
    public class ClassTestCaseDAO:Conexao
    {

        #region Metodo Para Salvar 
         
        // class
        public void Salvar(ClassTestCase testCase)
        {
            try
            {
                AbrirConexao();
                comando = new MySqlCommand(@"INSERT INTO pessoa (id, TestName, Class, Package) VALUES (@id, @TestName, @Class, @Package)", conexao);

                comando.Parameters.AddWithValue("@nome", testCase.ID);
                comando.Parameters.AddWithValue("@TestName", testCase.TestName);
                comando.Parameters.AddWithValue("@Class", testCase.Class);
                comando.Parameters.AddWithValue("@Package", testCase.Package);
                
                comando.ExecuteNonQuery();
            }
            catch (Exception erro)
            {

                throw erro;
            }
            finally
            {
                FecharConexao();
            }
        }
        #endregion

        #region Metodo para listar no Daragridview

        public DataTable Listar()
        {
            try
            {
                AbrirConexao();

                DataTable DT = new DataTable();
                MySqlDataAdapter Da = new MySqlDataAdapter();

                comando = new MySqlCommand("SELECT * FROM TestCase ORDER BY nome", conexao);

                Da.SelectCommand = comando;

                Da.Fill(DT);

                return DT;
            }
            catch (Exception erro)
            {

                throw erro;
            }
            finally
            {
                FecharConexao();
            }
        }
        #endregion

        #region Metodo para Editar os dados da pessoa 

        public void Editar(ClassTestCase testCase)
        {
            try
            {
                AbrirConexao();

                comando = new MySqlCommand("UPDATE TestCase SET nome = @nome, sexo = @sexo, telefone = @telefone, celular = @celular, endereco = @endereco, bairro = @bairro, cidade = @cidade, estado = @estado WHERE ID = @ID ", conexao);

                comando.Parameters.AddWithValue("@nome", testCase.ID);
                comando.Parameters.AddWithValue("@TestName", testCase.TestName);
                comando.Parameters.AddWithValue("@Class", testCase.Class);
                comando.Parameters.AddWithValue("@Package", testCase.Package);

                comando.ExecuteNonQuery();

            }
            catch (Exception erro)
            {

                throw erro;
            }

            finally
            {
                FecharConexao();
            }
        }
        #endregion

        #region Metodo para Exclui os dados da pessoa

        public void Excluir(ClassTestCase testCase)
        {
            try
            {
                AbrirConexao();

                comando = new MySqlCommand("DELETE FROM  TestCase WHERE ID = @ID", conexao);

                comando.Parameters.AddWithValue("@Id", testCase.ID);

                comando.ExecuteNonQuery();


            }
            catch (Exception erro)
            {

                throw erro;
            }

            finally
            {
                FecharConexao();
            }
        }

        #endregion
    }
}
