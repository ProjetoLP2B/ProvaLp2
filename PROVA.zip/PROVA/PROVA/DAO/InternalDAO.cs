﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using MySql.Data.MySqlClient;

namespace backend1.DAO
{
    public class InternalDAO : DAO
    {
        MySqlCommand comando = null;
        public void inserir(Internal inter)
        {
            try
            {
                AbrirConexao();
                comando = new MySqlCommand("call INSERIR_INDICADOR(@idts,@idcud);", conexao);
                comando.Parameters.AddWithValue("@idts", inter.TScaffolding.getID());
                comando.Parameters.AddWithValue("@idcud", inter.Cut1.getCutID());

                if (comando.ExecuteNonQuery() > 0)
                    Console.WriteLine("INSERIDO COM SUCESSO");
            }
            catch (Exception erro)
            {
                Console.WriteLine(erro);
            }
            finally
            {
                FecharConexao();
            }
        }

        public List<Internal> lista = new List<Internal>();

        public List<Internal> List()
        {
            try
            {
                AbrirConexao();
                DataTable objDataTable = null;
                //Se quiser personalizar a busca
                string strSQL = "select  * from internal";
                objDataTable = ExecutaConsultar(CommandType.Text, strSQL);
                if (objDataTable.Rows.Count <= 0)
                {
                    return lista;
                }
                foreach (DataRow objLinha in objDataTable.Rows)
                {
                    TestScaffolding testsca = new TestScaffolding();
                    CUT cut = new CUT();

                    testsca.setID(objLinha["id_indicador"] != DBNull.Value ? Convert.ToString(objLinha["id_indicador"]) : "");
                    cut.setID(objLinha["id_indicador"] != DBNull.Value ? Convert.ToString(objLinha["id_indicador"]) : "");
                    cut.setCompName(objLinha["componentName"] != DBNull.Value ? Convert.ToString(objLinha["componentName"]) : "");
                    Internal indicador = new Internal(cod_stscaf, cod_idcud);

                    lista.Add(indicador);
                }
                return lista;
            }
            catch (Exception)
            {
                return lista;
            }
            finally
            {
                FecharConexao();
            }
        }
        public void editar(Indicador indicador)
        {
            try
            {
                AbrirConexao();
                comando = new MySqlCommand("call atualizar_indicador(@id,@nome,@descricao,@observacao);", conexao);
                comando.Parameters.AddWithValue("@id", indicador.id);
                comando.Parameters.AddWithValue("@nome", indicador.nome);
                comando.Parameters.AddWithValue("@descricao", indicador.descricao);
                comando.Parameters.AddWithValue("@observacao", indicador.observacao);

                if (comando.ExecuteNonQuery() > 0)
                    Console.WriteLine("ATUALIZADO COM SUCESSO");

            }
            catch (Exception erro)
            {
                throw erro;
            }
            finally
            {
                FecharConexao();
            }
        }

        public void exclui(Indicador indicador)
        {
            try
            {
                AbrirConexao();
                comando = new MySqlCommand("call delete_indicador(@indicadorid);", conexao);
                comando.Parameters.AddWithValue("@indicadorid", indicador.id);


                if (comando.ExecuteNonQuery() > 0)
                    Console.WriteLine("EXCLUIDO COM SUCESSO");

            }
            catch (Exception erro)
            {
                throw erro;
            }
            finally
            {
                FecharConexao();
            }
        }

    }
}
