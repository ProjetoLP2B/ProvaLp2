﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PROVA
{
    public partial class frmCut : Form
    {
        public frmCut()
        {
            InitializeComponent();
        }

        private void btnSairCUT_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
