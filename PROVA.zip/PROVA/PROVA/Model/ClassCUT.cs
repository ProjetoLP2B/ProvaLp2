﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test
{
    public class ClassCUT
    {
        public int ID { get; set; }
        public string ComponentName { get; set; }
        public string Package { get; set; }
    }
}
