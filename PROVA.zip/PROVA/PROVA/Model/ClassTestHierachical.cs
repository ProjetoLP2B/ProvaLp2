﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test
{
    public class ClassTestHierachical
    {
        public  string ID { get; set; }
        public  string TestName { get; set; }
        public  string Class { get; set; }
        public  string Package { get; set; }
    }
}
