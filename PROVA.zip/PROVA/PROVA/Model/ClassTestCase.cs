﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test
{
    public class ClassTestCase
    {
        public int ID  { get; set; }
        public string TestName { get; set; }
        public string Class { get; set; }
        public string Package  { get; set; }

    }
}
