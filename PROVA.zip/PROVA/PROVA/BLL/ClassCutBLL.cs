﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using test.Model;
using test.Dao;
using System.Data;



namespace test.BLL
{
    public class ClassCutBLL
    {
        ClassCutDAO cutDAO = new ClassCutDAO();

        #region Metodo para Salvar 

        public void Salvar(ClassCUT cut)
        {
            try
            {
                cutDAO.Salvar(cut);
            }
            catch (Exception erro)
            {
                throw erro;
            }
        }
        #endregion

        #region Metodo para Listar

        public DataTable Listar()
        {
            try
            {
                DataTable Dt = new DataTable();

                Dt = cutDAO.Listar();

                return Dt;

            }
            catch (Exception erro)
            {

                throw erro;
            }
        }
        #endregion

        #region Metodo para Editar 

        public void Editar(ClassCUT cut)
        {
            try
            {
                cutDAO.Editar(cut);

            }
            catch (Exception erro)
            {

                throw erro;
            }
        }

        #endregion

        #region Metodo para Excluir

        public void Excluir(ClassCUT cut)
        {
            try
            {
                cutDAO.Excluir(cut);

            }
            catch (Exception erro)
            {

                throw erro;
            }
        }

        #endregion
    }
}
